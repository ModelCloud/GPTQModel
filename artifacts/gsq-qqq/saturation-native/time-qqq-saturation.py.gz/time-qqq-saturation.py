import argparse
import hashlib
import json
import sys
from pathlib import Path
import os, subprocess, time
uuid = os.environ['CUDA_VISIBLE_DEVICES']
for i in range(3):
    row = subprocess.check_output(['nvidia-smi', '--id='+uuid, '--query-gpu=index,pci.bus_id,uuid,name,memory.used,utilization.gpu', '--format=csv,noheader,nounits'], text=True).strip()
    fields = [x.strip() for x in row.split(',')]
    processes = subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid', '--format=csv,noheader'], text=True)
    assert fields[2] == uuid and int(fields[4]) <= 8 and int(fields[5]) == 0 and uuid not in processes, row
    print('IDLE', row, flush=True)
    time.sleep(1)

import torch

p = argparse.ArgumentParser()
p.add_argument('binary')
p.add_argument('--tokens', type=int, default=17)
a = p.parse_args()
torch.ops.load_library(a.binary)
import gptqmodel.nn_modules.qlinear.qqq as qqq
qqq.qqq_runtime_available = lambda: True
qqq.qqq_gemm = torch.ops.gptqmodel_qqq.qqq_gemm
sys.path.insert(0, str(Path.cwd() / 'tests'))
from test_qqq_jit import _build_grouped_parity_modules
native, reference = _build_grouped_parity_modules([(15, 18.0, 126), (11, .5, 2)])
x = torch.zeros(a.tokens, 256, dtype=torch.float16, device='cuda')
x[:, 0] = 1
expected = reference(x.cpu()).cuda()
for _ in range(20):
    y = native(x)
torch.cuda.synchronize()
assert torch.equal(y, expected)
print('IDENTITY', json.dumps({'binary': a.binary, 'sha256': hashlib.sha256(Path(a.binary).read_bytes()).hexdigest(), 'tokens': a.tokens, 'torch': str(torch.__version__), 'cuda': torch.version.cuda, 'device': str(torch.cuda.get_device_properties(0))}), flush=True)
torch.cuda.cudart().cudaProfilerStart()
y = native(x)
torch.cuda.synchronize()
torch.cuda.cudart().cudaProfilerStop()
assert torch.equal(y, expected)

# Run this script without NCU for authoritative warmed event timing.
starts = [torch.cuda.Event(enable_timing=True) for _ in range(100)]
ends = [torch.cuda.Event(enable_timing=True) for _ in range(100)]
for start, end in zip(starts, ends):
    start.record()
    native(x)
    end.record()
torch.cuda.synchronize()
values = sorted(start.elapsed_time(end) * 1000 for start, end in zip(starts, ends))
print('TIMING_US', json.dumps({'median': (values[49]+values[50])/2, 'p10': values[9], 'p90': values[89], 'samples': values}), flush=True)
assert torch.equal(native(x), expected)
