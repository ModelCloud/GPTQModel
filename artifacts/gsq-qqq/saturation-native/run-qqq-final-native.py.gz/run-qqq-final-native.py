import os, subprocess, time
uuid = os.environ['CUDA_VISIBLE_DEVICES']
for i in range(3):
    row = subprocess.check_output(['nvidia-smi', '--id='+uuid, '--query-gpu=index,pci.bus_id,uuid,name,memory.used,utilization.gpu', '--format=csv,noheader,nounits'], text=True).strip()
    fields = [x.strip() for x in row.split(',')]
    processes = subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid', '--format=csv,noheader'], text=True)
    assert fields[2] == uuid and int(fields[4]) <= 8 and int(fields[5]) == 0 and uuid not in processes, row
    print('IDLE', row, flush=True)
    time.sleep(1)
import torch, pytest
print('RUNTIME', torch.__version__, torch.version.cuda, torch.cuda.get_device_properties(0), flush=True)
raise SystemExit(pytest.main(['-q', '-s', 'tests/test_qqq_jit.py', 'tests/test_gsq_qqq_contract.py', '-k', 'grouped_cuda or native_reload']))
